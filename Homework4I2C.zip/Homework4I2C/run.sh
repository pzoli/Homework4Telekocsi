#!/bin/bash
java -jar target/Homework4I2C-0.0.1-SNAPSHOT-jar-with-dependencies.jar
